# webtech-prj-sciencedb
Create e knowledge base of scientific articles

# Descriere proiect

Ca cercetator vreau sa imi construiesc o baza de date de articole pe care le studiez

# Entitati

Articol
* Denumire
* Tip_Material
* Culoare
* Marime
* full text
* url

# Tehologii

* NodeJs 
* NodeAdmin
* MySQL

# ToDo
* install mysql [done]
* install node admin [done]
* create the database [done]

# Resources
* https://community.c9.io/t/setting-up-mysql/1718
* https://www.npmjs.com/package/nodeadmin